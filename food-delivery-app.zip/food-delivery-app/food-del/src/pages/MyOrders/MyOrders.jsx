import React from 'react'
import './MyOrders.css'

const MyOrders = () => {
  return (
    <div className='my-orders'>
      
    </div>
  )
}

export default MyOrders
